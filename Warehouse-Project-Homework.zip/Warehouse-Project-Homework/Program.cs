using System;
using Warehouse_Project_Homework;

public class Program
{
    static void Main(string[] args)
    {
        Management m = new Management();

        Employee emp1 = new Employee(1, "John", "Doe", "Manager", 5000);
        Employee emp2 = new Employee(2, "Jane", "Smith", "Assistant", 3000);

        m.addEmployee(emp1);
        m.addEmployee(emp2);

        m.listEmployees();

        Product prod1 = new Product(1, "Laptop", "China", 10, 1500);
        m.addProduct(prod1);
        Product prod2 = new Product(2, "Smartphone", "Korea", 20, 1000);
        m.addProduct(prod2);

        m.showProducts();

        Customer cust1 = new Customer(1, "Alice", "Johnson", "123456789", "123 Main St");
        m.addCustomer(cust1);

        Customer cust2 = new Customer(2, "John", "Michael", "987654321", "New York");
        m.addCustomer(cust2);

        m.showCustomers();

        m.removeCustomer(cust2);

        m.showCustomers();

        Order order1 = new Order(1, cust1, new List<Product> { prod1 }, "Processing");

        order1.addProduct(prod2);

        order1.removeProduct(prod1);

        order1.updateStatus("Transferred");
    }
}

