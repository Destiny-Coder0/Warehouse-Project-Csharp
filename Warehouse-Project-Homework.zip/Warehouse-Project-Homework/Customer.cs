using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse_Project_Homework
{
    public class Customer : Person
    {
        public string phoneNum { get; set; }
        public string address { get; set; }

        public Customer(int id, string name, string surname, string phoneNum, string address)
        {
            this.id = id;
            this.name = name;
            this.surname = surname;
            this.phoneNum = phoneNum;
            this.address = address;
        }
    }
}
