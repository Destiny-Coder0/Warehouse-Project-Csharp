using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse_Project_Homework
{
    public class Order : IProducts
    {
        public int id { get; set; }
        public Customer Customer { get; set; }
        public List<Product> Products { get; set; }
        public string status { get; set; }

        public Order(int id, Customer customer, List<Product> products, string status)
        {
            this.id = id;
            this.Customer = customer;
            this.Products = products;
            this.status = status;
        }

        public void addProduct(Product product)
        {
            Products.Add(product);
            Console.WriteLine("Product " + product.pName + " added to order " + id);
        }

        public void removeProduct(Product product)
        {
            if (Products.Contains(product))
            {
                Products.Remove(product);
                Console.WriteLine("Product removed from order " + id);
            }
            else
            {
                Console.WriteLine("Product not found in order.");
            }
        }

        public void updateStatus(string status)
        {
            this.status = status;
            Console.WriteLine("Order status updated to " + status);
        }
    }
}
