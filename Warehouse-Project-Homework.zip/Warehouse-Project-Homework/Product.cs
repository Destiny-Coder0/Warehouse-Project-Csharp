using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse_Project_Homework
{
        public class Product
        {
            public int pId { get; set; }
            public string pName { get; set; }

            public string origin { get; set; }
            public double quantity { get; set; }

            public double price { get; set; }

            public Product(int pId, string pName, string origin, double quantity, double price)
            {
                this.pId = pId;
                this.pName = pName;
                this.origin = origin;
                this.quantity = quantity;
                this.price = price;
            }

            public void updateQuantity(double quantity)
            {
                this.quantity = quantity;
                Console.WriteLine("Quantity updated to " + quantity);
            }

            public void updatePrice(double price)
            {
                this.price = price;
                Console.WriteLine("Price updated to " + price);
            }

        }
  }
