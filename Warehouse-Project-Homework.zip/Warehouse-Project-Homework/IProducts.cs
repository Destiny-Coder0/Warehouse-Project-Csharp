using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse_Project_Homework
{
    public interface IProducts
    {
        void addProduct(Product product);
        void removeProduct(Product product);
    }
}
