using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse_Project_Homework
{
    public class Management : IProducts
    {
        public List<Employee> employees = new List<Employee>();
        public List<Product> products = new List<Product>();
        public List<Customer> customers = new List<Customer>();

        public void addEmployee(Employee e)
        {
            if (employees.Any(e => e.Equals(e)))
            {
                Console.WriteLine("Employee with ID " + e.id + " already exists.");
                return;
            }

            employees.Add(e);
            Console.WriteLine("Employee " + e.name + " " + e.surname + " added.");
        }

        public void removeEmployee(Employee e)
        {
            if (employees.Any(e => e.Equals(e)))
            {
                employees.Remove(e);
                Console.WriteLine("Employee " + e.name + " " + e.surname + " removed.");
                return;
            }

            Console.WriteLine("Employee with ID " + e.id + " does not exist.");
        }

        public void addProduct(Product p)
        {
            if (products.Any(p => p.pId == p.pId))
            {
                Console.WriteLine("Product with ID " + p.pId + " already exists.");
                return;
            }

            products.Add(p);
            Console.WriteLine("Product " + p.pName + " added.");
        }

        public void removeProduct(Product p)
        {
            if (products.Contains(p))
            {
                products.Remove(p);
                Console.WriteLine("Product removed from inventory.");
            }
            else
            {
                Console.WriteLine("Product not found in inventory.");
            }
        }

        public void listEmployees()
        {
            Console.WriteLine("Employees: ");
            foreach (Employee employee in employees)
            {
                Console.WriteLine("ID: " + employee.id + " Name: " + employee.name + " Surname: " + employee.surname + " Position: " + employee.position + " Salary: " + employee.salary);
            }
        }

        public double calculateTotalPrice()
        {
            double totalPrice = 0;
            foreach (Product product in products)
            {
                totalPrice += product.price * product.quantity;
            }
            return totalPrice;
        }

        public void showProducts()
        {
            Console.WriteLine("Product List: ");
            foreach (Product product in products)
            {
                Console.WriteLine("ID: " + product.pId + " Name: " + product.pName + " Origin: " + product.origin + " Quantity: " + product.quantity + " Price: " + product.price);
            }
        }

        public void addCustomer(Customer c)
        {
            if (customers.Any(c => c.Equals(c)))
            {
                Console.WriteLine("Customer with ID " + c.id + " already exists.");
                return;
            }

            customers.Add(c);
            Console.WriteLine("Customer " + c.name + " " + c.surname + " added.");
        }

        public void removeCustomer(Customer c)
        {
            if (customers.Any(c => c.Equals(c)))
            {
                customers.Remove(c);
                Console.WriteLine("Customer " + c.name + " " + c.surname + " removed.");
            }

            Console.WriteLine("Customer with ID " + c.id + " does not exist.");
        }
        public void showCustomers()
        {
            Console.WriteLine("Customer List: ");
            foreach (Customer customer in customers)
            {
                Console.WriteLine("ID: " + customer.id + " Name: " + customer.name + " Surname: " + customer.surname + " Phone Number: " + customer.phoneNum + " Address: " + customer.address);
            }
        }
    }
}
