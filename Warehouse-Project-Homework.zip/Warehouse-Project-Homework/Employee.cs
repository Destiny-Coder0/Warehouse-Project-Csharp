using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Warehouse_Project_Homework
{
    public class Employee : Person
    {
        public string position { get; set; }
        public double salary { get; set; }

        public Employee(int id, string name, string surname, string position, double salary)
        {
            this.id = id;
            this.name = name;
            this.surname = surname;
            this.position = position;
            this.salary = salary;
        }

        public void updateSalary(double salary)
        {
            this.salary = salary;
            Console.WriteLine("Salary updated to " + salary);
        }

        public void updatePosition(string position)
        {
            this.position = position;
            Console.WriteLine("Position updated to " + position);
        }
}
}
